#!/usr/bin/env bash

APP_NAME=jjche-boot-demo.jar

#cd /home/user1/demo/
#mv -f $APP_NAME  $APP_NAME.bak
#cp -rf ./tmp/*.jar ./

