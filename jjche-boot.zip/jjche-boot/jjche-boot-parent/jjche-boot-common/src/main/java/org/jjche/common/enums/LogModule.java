package org.jjche.common.enums;

/**
 * <p>
 * 日志模块
 * </p>
 *
 * @author miaoyj
 * @version 1.0.0-SNAPSHOT
 * @since 2021-08-20
 */
public interface LogModule {
    /**
     * Constant <code>LOG_MODULE_LOGIN="认证"</code>
     */
    String LOG_MODULE_LOGIN = "认证";
}
