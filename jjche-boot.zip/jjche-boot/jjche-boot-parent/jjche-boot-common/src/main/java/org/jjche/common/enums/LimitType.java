package org.jjche.common.enums;

/**
 * 限流枚举
 *
 * @author /
 * @version 1.0.8-SNAPSHOT
 */
public enum LimitType {
    // 默认
    CUSTOMER,
    //  by ip addr
    IP
}
