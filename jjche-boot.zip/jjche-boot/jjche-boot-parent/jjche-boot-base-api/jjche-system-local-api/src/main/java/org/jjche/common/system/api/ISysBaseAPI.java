package org.jjche.common.system.api;

import org.jjche.common.api.CommonAPI;

/**
 * <p>
 * 单体
 * </p>
 *
 * @author miaoyj
 * @since 2022-08-09
 */
public interface ISysBaseAPI extends CommonAPI {
}
