package com.boot.mybatis.base;

/**
 * <p>MyBaseMapper interface.</p>
 *
 * @author miaoyj
 * @version 1.0.0-SNAPSHOT
 */
public interface MyBaseMapper {
}
