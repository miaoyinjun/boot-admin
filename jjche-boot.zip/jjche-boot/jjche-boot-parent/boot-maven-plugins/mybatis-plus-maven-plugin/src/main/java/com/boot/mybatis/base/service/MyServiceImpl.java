package com.boot.mybatis.base.service;

/**
 * <p>
 * 为生成代码临时创建
 * </p>
 *
 * @author miaoyj
 * @version 1.1.0
 * @since 2020-07-16
 */
public class MyServiceImpl {
}
