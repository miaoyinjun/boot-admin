package com.boot.admin.core.base;

/**
 * <p>
 * 为生成代码临时创建
 * </p>
 *
 * @author miaoyj
 * @since 2020-09-10
 * @version 1.0.8-SNAPSHOT
 */
public class BaseController {
}
